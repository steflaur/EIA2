declare namespace monkeyBusiness {
    let crc2: CanvasRenderingContext2D;
}
